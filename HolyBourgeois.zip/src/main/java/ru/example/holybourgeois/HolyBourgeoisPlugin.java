package ru.example.holybourgeois;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class HolyBourgeoisPlugin extends JavaPlugin implements Listener {
    private File playersFile;
    private FileConfiguration playersConfig;

    private final String GUI_TITLE = "⚙ Буржуй"; // ⚙ Буржуй
    private final int ASSORTMENT_SIZE = 7;

    private List<ShopItem> assortment = new ArrayList<>();
    private long assortmentRefreshMillis = 4 * 60 * 60 * 1000L; // 4 часа

    private Random random = new Random();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadPlayersConfig();
        loadAssortmentFromConfig();

        Bukkit.getPluginManager().registerEvents(this, this);

        // Планировщик обновления ассортимента
        new BukkitRunnable() {
            @Override
            public void run() {
                refreshAssortment();
                getLogger().info("Assortment refreshed.");
            }
        }.runTaskTimer(this, 20L, assortmentRefreshMillis / 50L);

        // Команда открытия магазина
        Objects.requireNonNull(getCommand("burzhui")).setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Только игроки могут использовать эту команду.");
                return true;
            }
            openShop((Player) sender);
            return true;
        });

        getLogger().info("HolyBourgeois enabled");
    }

    @Override
    public void onDisable() {
        savePlayersConfig();
        saveAssortmentToConfig();
    }

    private void loadPlayersConfig() {
        playersFile = new File(getDataFolder(), "players.yml");
        if (!playersFile.exists()) {
            playersFile.getParentFile().mkdirs();
            saveResource("players.yml", false);
        }
        playersConfig = YamlConfiguration.loadConfiguration(playersFile);
    }

    private void savePlayersConfig() {
        try {
            playersConfig.save(playersFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadAssortmentFromConfig() {
        assortment.clear();
        FileConfiguration cfg = getConfig();
        if (cfg.contains("assortment.items")) {
            for (int i = 0; i < ASSORTMENT_SIZE; i++) {
                String matName = cfg.getString("assortment.items." + i + ".material", "DIAMOND");
                double price = cfg.getDouble("assortment.items." + i + ".price", 10.0);
                Material mat = Material.getMaterial(matName);
                if (mat == null) mat = Material.DIAMOND;
                assortment.add(new ShopItem(mat, price));
            }
        } else {
            refreshAssortment();
        }
    }

    private void saveAssortmentToConfig() {
        for (int i = 0; i < assortment.size(); i++) {
            ShopItem s = assortment.get(i);
            getConfig().set("assortment.items." + i + ".material", s.material.name());
            getConfig().set("assortment.items." + i + ".price", s.basePrice);
        }
        saveConfig();
    }

    private void refreshAssortment() {
        assortment.clear();
        Material[] pool = {
                Material.DIAMOND, Material.IRON_INGOT, Material.GOLD_INGOT, Material.EMERALD,
                Material.COAL, Material.REDSTONE, Material.ENDER_PEARL, Material.ARROW, Material.BREAD
        };
        List<Material> materials = new ArrayList<>(Arrays.asList(pool));
        Collections.shuffle(materials);
        for (int i = 0; i < ASSORTMENT_SIZE; i++) {
            Material mat = materials.get(i % materials.size());
            double basePrice = 10 + random.nextInt(90); // 10 - 99
            assortment.add(new ShopItem(mat, basePrice));
        }
        getConfig().set("assortment.lastRefresh", System.currentTimeMillis());
        saveAssortmentToConfig();
        saveConfig();
    }

    private void openShop(Player player) {
        Inventory inv = Bukkit.createInventory(null, 9, GUI_TITLE);
        for (int i = 0; i < assortment.size(); i++) {
            ShopItem s = assortment.get(i);
            ItemStack is = new ItemStack(s.material);
            ItemMeta meta = is.getItemMeta();
            meta.setDisplayName("§6" + s.material.name());
            List<String> lore = new ArrayList<>();
            lore.add("§7Цена за 1 шт: §e" + formatPrice(s.getPrice()));
            lore.add("§7Цена за стак (64 шт): §e" + formatPrice(s.getPrice() * 64));
            lore.add("");
            lore.add("§aКлик — продать 1 шт");
            lore.add("§aШифт-клик — продать стак (64 шт)");
            meta.setLore(lore);
            is.setItemMeta(meta);
            inv.setItem(i, is);
        }
        player.openInventory(inv);
    }

    private String formatPrice(double price) {
        return String.format("%.2f$", price);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();

        if (!event.getView().getTitle().equals(GUI_TITLE)) return;

        event.setCancelled(true);

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= assortment.size()) return;

        ShopItem item = assortment.get(slot);

        boolean isShiftClick = event.isShiftClick();

        int amountToSell = isShiftClick ? 64 : 1;
        int removed = removeItems(player, item.material, amountToSell);

        if (removed == 0) {
            player.sendMessage("§cУ вас нет подходящих предметов для продажи.");
            return;
        }

        double moneyGained = item.getPrice() * removed;
        giveMoney(player, moneyGained);
        player.sendMessage("§aВы продали §e" + removed + " шт " + item.material.name() + "§a за §e" + formatPrice(moneyGained));

        // Снижение цены при продаже стаком
        if (isShiftClick) {
            // за каждый стак - минус 1% от цены
            int stacksSold = removed / 64;
            for (int i = 0; i < stacksSold; i++) {
                item.multiplyPrice(0.99);
            }
            saveAssortmentToConfig();
        }

        // Репутация: +1 прогресс за сдачу 5 стак (320 шт)
        if (isShiftClick && removed >= 320) {
            addReputationProgress(player, 1);
        }

        // Обновляем GUI
        openShop(player);
    }

    private int removeItems(Player player, Material mat, int amount) {
        int toRemove = amount;
        int removed = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack == null) continue;
            if (stack.getType() == mat) {
                int stackAmount = stack.getAmount();
                if (stackAmount <= toRemove) {
                    removed += stackAmount;
                    toRemove -= stackAmount;
                    stack.setAmount(0);
                } else {
                    removed += toRemove;
                    stack.setAmount(stackAmount - toRemove);
                    toRemove = 0;
                }
                if (toRemove <= 0) break;
            }
        }
        player.updateInventory();
        return removed;
    }

    // Заглушка для экономики — добавь Vault API для работы с валютой
    private void giveMoney(Player player, double amount) {
        // TODO: интеграция с Vault/Economy
    }

    private void addReputationProgress(Player player, int progress) {
        String basePath = "players." + player.getUniqueId() + ".reputation";

        int curProgress = playersConfig.getInt(basePath + ".progress", 0);
        int level = playersConfig.getInt(basePath + ".level", 0);

        curProgress += progress;

        if (curProgress >= 5) {
            if (level < 10) {
                level++;
                player.sendMessage("§aВаша репутация Буржуя повысилась до уровня §6" + level + "§a!");
            }
            curProgress = 0;
        }

        playersConfig.set(basePath + ".progress", curProgress);
        playersConfig.set(basePath + ".level", level);
        savePlayersConfig();
    }

    private static class ShopItem {
        Material material;
        double basePrice;

        ShopItem(Material material, double basePrice) {
            this.material = material;
            this.basePrice = basePrice;
        }

        double getPrice() {
            return basePrice;
        }

        void multiplyPrice(double factor) {
            basePrice *= factor;
            if (basePrice < 0.01) basePrice = 0.01;
        }
    }
}
